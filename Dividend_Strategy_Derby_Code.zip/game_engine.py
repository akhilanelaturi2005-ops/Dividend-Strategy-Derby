
def calculate_score(income, risk):
    return income / (1 + risk)
